import*as n from"three";import{HOUSE as e,ROOF_GLASS as _}from"./layout.js";function U(l){const h=new n.Scene,u=new n.BoxGeometry(1,1,1),a=[],r=(t,c,x,m=n.FrontSide)=>{const y=new n.MeshBasicMaterial({color:new n.Color(t,c,x),side:m});return a.push(y),y},s=r(.22,.4,.04,n.BackSide),p=r(.48,.65,.06),i=r(.025,.018,.008),v=r(.62,.2,.008),d=r(.02,3.2,.015),M=r(.06,.045,.012),o=(t,c,x,m,y,w,B)=>{const S=new n.Mesh(u,B);S.position.set(t,c,x),S.scale.set(m,y,w),h.add(S)},f=(e.x0+e.x1)/2,b=(e.z0+e.z1)/2;o(f,e.height/2,b,e.x1-e.x0,e.height,e.z1-e.z0,s),o(f,-.015,b,e.x1-e.x0,.04,e.z1-e.z0,p);for(let t=0;t<24;t++){const c=.65+(t+.5)*8.3/24,x=n.MathUtils.smoothstep(c,1,5),m=r(.45+1.45*x,.025,.008);o(f,c,e.z1-.03,e.x1-e.x0-.2,8.3/24,.025,m),c>=1&&o(e.x1-.03,c,10,.025,8.3/24,12,m)}for(let t=e.x0;t<=e.x1;t+=3.8)o(t,4.8,e.z1-.06,.09,8.4,.08,i);for(const t of[4,8,12,16])o(e.x1-.06,5,t,.08,8,.09,i);o(f,4.5,e.z1-.07,e.x1-e.x0,.1,.08,i),o(e.x1-.07,4.5,10,.08,.1,12,i);for(const t of _)o((t.x0+t.x1)/2,e.height-.03,(t.z0+t.z1)/2,t.x1-t.x0,.025,t.z1-t.z0,v);o(17.5,.48,8.5,3.9,.96,1.35,M),o(17.5,3.2,8.5,3.32,.055,.18,d),o(16,2.66,12.8,1.65,.055,.22,d),o(8,7.5,7,5,.08,3,r(.12,.75,.025));const z=new n.PMREMGenerator(l);let g;try{g=z.fromScene(h,.035,.1,80,{size:128,position:new n.Vector3(16.6,1.35,6.4)}),g.texture.name="kitchen-room-radiance"}finally{z.dispose(),u.dispose(),a.forEach(t=>t.dispose())}return g}const E=`
  #include <begin_vertex>
  vec3 brushScale = vec3(length(instanceMatrix[0].xyz), length(instanceMatrix[1].xyz), length(instanceMatrix[2].xyz));
  vec3 brushPosition = (position + 0.5) * brushScale;
  vBrushUv = abs(normal.y) > 0.5 ? brushPosition.zx : abs(normal.x) > 0.5 ? brushPosition.zy : brushPosition.xy;
  // The anisotropic tangent frame uses the same physical grain direction.
  vUv = vBrushUv;
`,C=`
  #include <roughnessmap_fragment>
  // Filter each frequency before it reaches Nyquist, not after the two
  // signals beat together into visible moire at normal walking distances.
  float phaseA = vBrushUv.x * 720.0, phaseB = vBrushUv.x * 1040.0;
  float brush = sin(phaseA) * (1.0 - smoothstep(1.0, 2.6, fwidth(phaseA)))
    + 0.35 * sin(phaseB) * (1.0 - smoothstep(1.0, 2.6, fwidth(phaseB)));
  roughnessFactor = clamp(roughnessFactor + brush * 0.018, 0.22, 0.48);
`;function P(l){const h=U(l.renderer),u={uSteelDay:{value:new n.Vector3(1,1,1)},uSteelLamp:{value:new n.Vector3(.18,.17,.15)},uSteelFill:{value:new n.Vector3(.5,.49,.48)}},a=new n.MeshPhysicalMaterial({name:"brushed-stainless",color:13225167,metalness:1,roughness:.32,anisotropy:.35,anisotropyRotation:0,envMap:h.texture,envMapIntensity:1}),r=n.ShaderChunk.envmap_physical_pars_fragment.replaceAll("envMapColor.rgb * envMapIntensity","(envMapColor.r * uSteelDay + envMapColor.g * uSteelLamp + envMapColor.b * uSteelFill) * envMapIntensity");return a.onBeforeCompile=s=>{Object.assign(s.uniforms,u),s.vertexShader=`varying vec2 vBrushUv;
`+s.vertexShader.replace("#include <begin_vertex>",E),s.fragmentShader=`varying vec2 vBrushUv;
uniform vec3 uSteelDay;
uniform vec3 uSteelLamp;
uniform vec3 uSteelFill;
`+s.fragmentShader.replace("#include <envmap_physical_pars_fragment>",r).replace("#include <roughnessmap_fragment>",C)},a.customProgramCacheKey=()=>"brushed-stainless-room-v1",a.onBeforeRender=()=>{const s=l.night,p=l.hemi.color,i=((1-s)*(.72+.28*Math.min(1.3,l.hemi.intensity/1.25))+s*.025)*(1-.24*l.veil);u.uSteelDay.value.set(i*(.88+p.r*.12),i*(.88+p.g*.12),i*(.88+p.b*.12));const v=.18+.82*s;u.uSteelLamp.value.set(v,v*.97,v*.94)},a.addEventListener("dispose",()=>h.dispose()),a.userData.stainless={uniforms:u,probeSize:128,textureBytes:h.width*h.height*8},a}export{P as createStainless};
